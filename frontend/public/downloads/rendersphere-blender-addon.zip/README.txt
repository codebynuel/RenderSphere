RenderSphere Blender Add-on

Install this zip from Blender: Edit > Preferences > Add-ons > Install.
After enabling it, paste your RenderSphere access key into the add-on preferences.
Default server URL in this package: http://localhost:3000
