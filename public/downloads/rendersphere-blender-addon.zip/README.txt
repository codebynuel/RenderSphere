RenderSphere Blender Add-on

Install this zip from Blender: Edit > Preferences > Add-ons > Install.
After enabling it, paste your RenderSphere API key into the add-on preferences.
